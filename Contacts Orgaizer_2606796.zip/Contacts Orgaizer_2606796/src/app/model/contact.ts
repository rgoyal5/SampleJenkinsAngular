/*Model Class For Contact*/
export class Contact {

    public title:string;
    public firstName:string;
    public lastName:string;
    public mobile1:number;
    public mobile2:number;
    public email:string;
    public gender:string;

}
